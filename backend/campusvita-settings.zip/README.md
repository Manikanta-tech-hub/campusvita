# CampusVita Admin Settings implementation

This package contains the Settings page and its API client for the existing
CampusVita repository.

Files:
- frontend/app/admin/settings/page.tsx
- frontend/app/lib/settingsApi.ts
- campusvita-settings.patch

The implementation uses the existing backend endpoints:
- GET /profile
- PUT /profile
- POST /profile/upload-image
- POST /change-password

No new MongoDB collection or settings record is introduced.
The browser only uses localStorage for the existing access token; settings
values are loaded from and persisted through the authenticated backend.

Apply the patch from the repository root:
    git apply campusvita-settings.patch
